//
//  RequestsHelp.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 9/21/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation

class RequestsHelp {
    struct Constant {
        struct Oauth {
            static let nonce = "89601180"
            static let timestamp = "1305583298"
            static let consumerKey = "2f40fdbe582377d58486aa2e347bb833"
            static let signatureMethod = "HMAC-SHA1"
            static let version = "1.0"
            static let callBack = "http%3A%2F%2Fwww.example.com"
            static let secretKey = "ad46c09ecdbe73d5"
        }
        static let urlAPI = "GET&http%3A%2F%2Fwww.flickr.com%2Fservices%2F"
    }
    
    internal func getOauthSignatureForRequestToken() -> String {
        let baseString = Constant.urlAPI.appending("oauth%2Frequest_token&oauth_callback%3D\(Constant.Oauth.callBack)%26oauth_consumer_key%3D\(Constant.Oauth.consumerKey)%26oauth_nonce%3D\(Constant.Oauth.nonce)%26oauth_signature_method%3D\(Constant.Oauth.signatureMethod)%26oauth_timestamp%3D\(Constant.Oauth.timestamp)%26oauth_version%3D\(Constant.Oauth.version)")
        var oauthSignature = baseString.hmac(algorithm: .SHA1, key: "\(Constant.Oauth.secretKey)&")
        oauthSignature.characters.removeLast()
        print("Key: \(oauthSignature)")
        return oauthSignature
    }
    
    internal func getOuathSignatureForAuthorizationToken(token: String, verifier: String, tokenSecret: String) -> String {
        let baseString = Constant.urlAPI.appending("oauth%2Faccess_token&oauth_consumer_key%3D\(Constant.Oauth.consumerKey)%26oauth_nonce%3D\(Constant.Oauth.nonce)%26oauth_signature_method%3D\(Constant.Oauth.signatureMethod)%26oauth_timestamp%3D\(Constant.Oauth.timestamp)%26oauth_token%3D\(token)%26oauth_verifier%3D\(verifier)%26oauth_version%3D\(Constant.Oauth.version)")
        let newKey = "\(Constant.Oauth.secretKey)&\(tokenSecret)"
        var oauthSignature = baseString.hmac(algorithm: .SHA1, key: newKey)
        oauthSignature.characters.removeLast()
        print("Key1: \(oauthSignature)")
        return oauthSignature
    }
}

