//
//  SingInVCFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 9/27/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import UIKit

class SingInVCFlickrX: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    private let dataDecomposition = DecompositionFlickrX.shared
    private let dataManager = OuathFlickrX.shared
    private var tokenSecret = ""
    private var user: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func buttonSignIn(_ sender: Any) {
        login()
    }

    func login() {
        dataManager.getRequestToken {[weak self] (data) in
            guard let strongSelf = self else { return }
            
            guard let tokens = strongSelf.dataDecomposition.getOauthTokens(data: data!) else { return }
            
            DispatchQueue.main.async {
                strongSelf.tokenSecret = tokens.oauthTokenSecret
            }
            
            let stringURL = "https://www.flickr.com/services/oauth/authorize?oauth_token=\(tokens.oauthToken)"
            let url = URL(string: stringURL)
            let request = URLRequest(url: url!)
            strongSelf.webView.loadRequest(request)
        }
    }
}

extension SingInVCFlickrX: UIWebViewDelegate {
    
    func webView (_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        let appHost = "localhost"
        var result = false
        if request.url?.host == appHost {
            result = false
            
            if let data = request.url?.query {
                let tokens = dataDecomposition.getOauthVerifier(data: data)
                dataManager.getAuthorizationToken(verifier: tokens.oauthVerifier, token: tokens.oauthToken, tokenSecret: tokenSecret, receivedData: { [weak self] (data) in
                    guard let stringData = String.init(data: data!, encoding: .utf8) else { return }
                    guard let strongSelf = self else { return }
                    guard let tempUser = strongSelf.dataDecomposition.getAuthToken(data: stringData, verifier: tokens.oauthVerifier) else { return }
                    
                    DispatchQueue.main.async {
                        strongSelf.user = tempUser
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let viewController = storyboard.instantiateViewController(withIdentifier: "tapBar")
                        strongSelf.present(viewController, animated: true, completion: nil)
                    }
                })
            }
        } else {
            result = true
        }
        return result
    }
    
}

