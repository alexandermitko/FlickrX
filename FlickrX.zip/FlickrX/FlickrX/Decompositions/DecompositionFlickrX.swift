//
//  DecompositionFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 9/26/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation

class DecompositionFlickrX {
    
    static let shared = DecompositionFlickrX()
    
    private init() {}
    
    internal func getOauthTokens(data: Data) -> (oauthToken: String, oauthTokenSecret: String)? {
        if let stringData = String(data: data, encoding: .utf8) {
            let comp = stringData.components(separatedBy: "&")
            var keys = [String]()
            print("keys: \(comp)")
            for item in comp {
                keys.append(item.components(separatedBy: "=")[1])
            }
            print("oath: \(keys), oathSecret: \(keys)")
            return (oauthToken: keys[1], oauthTokenSecret: keys[2])
        }
        return nil
    }
    
    internal func getOauthVerifier(data: String) -> (oauthToken: String, oauthVerifier: String) {
        let comp = data.components(separatedBy: "&")
        var keys = [String]()
        for part in comp {
            keys.append(part.components(separatedBy: "=")[1])
        }
        return (oauthToken: keys[0], oauthVerifier: keys[1])
    }
    
    internal func getAuthToken(data: String, verifier: String) -> User? {
        let comp = data.components(separatedBy: "&")
        var keys = [String]()
        guard comp.count == 5 else { return nil }
        for part in comp {
            keys.append(part.components(separatedBy: "=")[1])
        }
        let result = User(fullname: keys[0], oauthToken: keys[1], tokenSecret: keys[2], userID: keys[3], username: keys[4], oauthVerifier: verifier)
        return result
    }
}
