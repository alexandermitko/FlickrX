//
//  SearchForPhotoFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 10/4/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation

class SearchForPhotoFlickrX {
    
    static let shared = SearchForPhotoFlickrX()
    let requestHelp = RequestsHelp()

    func urlWithSearchText (searchText: String, page: Int) -> URL {
        let escapedText = searchText.replacingOccurrences(of: " ", with: "")
        let stringURL = "https://api.flickr.com/services/rest?format=\(RequestsHelp.Constant.formatOfResponse)&method=\(RequestsHelp.Constant.photosSearchFlickr)&api_key=\(RequestsHelp.Constant.Oauth.consumerKey)&text=\(escapedText)&per_page=10&page=\(page)"
        let url = URL(string: stringURL)!
        return url
}

/*static let shared = SearchForPhotoFlickrX()
let requestHelp = RequestsHelp()


func urlWithSearchText (searchText: String, page: Int, receivedData: @escaping(Data?) -> ()) {
    let escapedText = searchText.replacingOccurrences(of: " ", with: "")
    let stringURL = "https://api.flickr.com/services/rest?format=\(RequestsHelp.Constant.formatOfResponse)&method=\(RequestsHelp.Constant.photosSearchFlickr)&api_key=\(RequestsHelp.Constant.Oauth.consumerKey)&text=\(escapedText)&per_page=10&page=\(page)"
    guard let url = URL(string: stringURL) else { return }
    let request = URLRequest(url: url)
    
    let task = session.dataTask(with: request) { (data, response, error) in
        guard let tempData = data else { return }
        receivedData(tempData)
    }
    task.resume()
}
}*/
