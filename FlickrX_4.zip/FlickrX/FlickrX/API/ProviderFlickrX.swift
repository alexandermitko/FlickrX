//
//  ProviderFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 10/5/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation
class ProviderFlickrX {
    let requestHelp = RequestsHelp()
    let session = URLSession.shared
}
