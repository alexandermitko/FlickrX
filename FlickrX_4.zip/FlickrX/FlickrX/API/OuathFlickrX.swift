//
//  OuathFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 9/21/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation
class OuathFlickrX {
    
    static let shared = OuathFlickrX()
    let requestHelp = RequestsHelp()
    
    func getRequestToken(receivedData: @escaping(Data?) -> ()) {
        let signature = requestHelp.getOauthSignatureForRequestToken()
        let stringURL = "https://www.flickr.com/services/oauth/request_token?oauth_callback=\(RequestsHelp.Constant.Oauth.callBackForRequest)&oauth_consumer_key=\(RequestsHelp.Constant.Oauth.consumerKey)&oauth_nonce=\(RequestsHelp.Constant.Oauth.nonce)&oauth_timestamp=\(RequestsHelp.Constant.Oauth.timestamp)&oauth_signature_method=\(RequestsHelp.Constant.Oauth.signatureMethod)&oauth_version=\(RequestsHelp.Constant.Oauth.version)&oauth_signature=\(signature)%3D"
        guard let url = URL(string: stringURL) else { return }
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { (data, responds, error) in
            guard let resumeData = data else { return }
            receivedData(resumeData)
        }
        task.resume()
    }
    
    func getAuthorizationToken(verifier: String, token: String, tokenSecret: String, receivedData: @escaping(Data?) -> ()) {
        let signature = requestHelp.getOuathSignatureForAuthorizationToken(token: token, verifier: verifier, tokenSecret: tokenSecret)
        let stringURL = "https://www.flickr.com/services/oauth/access_token?oauth_nonce=\(RequestsHelp.Constant.Oauth.nonce)&oauth_timestamp=\(RequestsHelp.Constant.Oauth.timestamp)&oauth_token=\(token)&oauth_verifier=\(verifier)&oauth_consumer_key=\(RequestsHelp.Constant.Oauth.consumerKey)&oauth_signature_method=\(RequestsHelp.Constant.Oauth.signatureMethod)&oauth_version=\(RequestsHelp.Constant.Oauth.version)&oauth_signature=\(signature)%3D"
        guard let url = URL(string: stringURL) else { return }
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { (data, responds, error) in
            guard let resumeData = data else { return }
            receivedData(resumeData)
        }
        task.resume()
    }
}

