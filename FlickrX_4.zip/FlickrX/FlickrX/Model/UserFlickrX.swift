//
//  UserFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 9/26/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import Foundation

class User {
    var fullname: String
    var oauthToken: String
    var tokenSecret: String
    var userID: String
    var username: String
    var oauthVerifier: String
    
    internal init(fullname: String, oauthToken: String, tokenSecret: String, userID: String, username: String, oauthVerifier: String) {
        self.fullname = fullname
        self.oauthToken = oauthToken
        self.tokenSecret = tokenSecret
        self.userID = userID
        self.username = username
        self.oauthVerifier = oauthVerifier
        
    }
}
