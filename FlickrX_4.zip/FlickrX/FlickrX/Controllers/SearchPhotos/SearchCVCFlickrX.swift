//
//  SearchCVCFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 10/3/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import UIKit

class SearchCVCFlickrX: UICollectionViewController {
    @IBOutlet var searchBar: UISearchBar!
    private let dataSearch = SearchForPhotoFlickrX.shared
    private var page = 1
    private var photoDictionaries = [Any]()
    //private let dataParaser
    private let leftAndRightPaddings: CGFloat = 32.0
    private let numberOfItemsPerOneRaw: CGFloat = 3.0
    private let height: CGFloat = 30.0
    
    struct Storyboard {
        static let searchPhotoCell = "SearchPhotosCell"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView?.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        let width = ((collectionView!.frame.width) - leftAndRightPaddings) / (numberOfItemsPerOneRaw)
        let layout = collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width + height)
        
        
    }
    //Переделать под Swift 4
    func fetchPhotos() {
        let session = URLSession.shared
        let url: URL
        if !self.searchBar.text!.isEmpty {
            url = dataSearch.urlWithSearchText(searchText: searchBar.text!, page: page)
        } else {
            url = dataSearch.urlWithSearchText(searchText: "Stars", page: page)
        }
        let request = URLRequest(url: url)
        let task = session.dataTask(with: request) { (data, response, error) in
            if error == nil {
                let tempData = data
                do {
                    let responseDictionary = try JSONSerialization.jsonObject(with: data!, options:[])
               
                        print()
                    
                } catch let error{
                    print(error)
                }
            }
        }
    }
    
    
    // MARK: UICollectionViewDataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return 10
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Storyboard.searchPhotoCell, for: indexPath) as! SearchForPhotosCVCFlickrX
        cell.photosSearchCell.image = UIImage(named: "NoImage" + ".png")
        
        
        return cell
    }
    
    // MARK: UICollectionViewDelegate
    
    /*
     // Uncomment this method to specify if the specified item should be highlighted during tracking
     override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
     return true
     }
     */
    
    /*
     // Uncomment this method to specify if the specified item should be selected
     override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
     return true
     }
     */
    
    /*
     // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
     override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
     return false
     }
     
     override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
     return false
     }
     
     override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
     
     }
     */
    
}
