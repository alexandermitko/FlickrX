//
//  SearchForPhotosCVCFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 10/3/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import UIKit

class SearchForPhotosCVCFlickrX: UICollectionViewCell {
    
    @IBOutlet weak var photosSearchCell: UIImageView!
    
    
}
