//
//  YouTVCFlickrX.swift
//  FlickrX
//
//  Created by Aliaksandr Mitsko on 10/2/17.
//  Copyright © 2017 Aliaksandr Mitsko. All rights reserved.
//

import UIKit

class YouTVCFlickrX: UITableViewController {
    @IBOutlet weak var photosCount: UILabel!
    @IBOutlet weak var followersCount: UILabel!
    @IBOutlet weak var followingCount: UILabel!
    @IBOutlet weak var profilePhoto: UIImageView!
    @IBOutlet weak var headerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }



}
